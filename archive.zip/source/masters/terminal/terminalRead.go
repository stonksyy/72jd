package terminal

// Read will directly read from the terminal and make it acceptable as an io.reader
func (term *Terminal) Read(buf []byte) (int, error) {
	term.mutex.Lock()
	defer term.mutex.Unlock()
	return term.wr.Read(buf)
}