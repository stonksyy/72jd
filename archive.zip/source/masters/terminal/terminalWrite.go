package terminal

import "fmt"

// Print will write the data using the sprint
func (term *Terminal) Print(data ...interface{}) (int, error) {
	return term.wr.Write([]byte(fmt.Sprint(data...)))
}

// Println writes using the same interface as Print but wraps within a ln
func (term *Terminal) Println(data ...interface{}) (int, error) {
	return term.Print(append(data, "\r\n")...)
}

// Write makes the interface acceptable inside an io.writer
func (term *Terminal) Write(data []byte) (int, error) {
	return term.wr.Write(data)
}

func (term *Terminal) Clear() (int, error) {
	return term.Write([]byte("\x1bc"))
}