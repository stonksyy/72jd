package masters

import (
	"hajime/source"
	"os"

	"golang.org/x/crypto/ssh"
)

//Server maintains a object which can be passed through the startup stages
type Server struct {
	server *ssh.ServerConfig
	Config *ServerConfig
}

//ServerConfig implements the configuration structure
type ServerConfig struct {
	Port     int    `json:"server.port"`
	Listener string `json:"server.listener"`
	Key      string `json:"server.privateKey"`
}

//Configure will configure the server before passing it forwards
func Configure() error {
	server := &Server{
		Config: new(ServerConfig),
		server: &ssh.ServerConfig{
			NoClientAuth: true,
			ServerVersion: "SSH-2.0-H",
		},
	}

	err := source.Options.MarshalFromPath(&server.Config, "server")
	if err != nil {
		return err
	}

	content, err := os.ReadFile(server.Config.Key)
	if err != nil {
		return err
	}

	private, err := ssh.ParsePrivateKey(content)
	if err != nil {
		return err
	}

	server.server.AddHostKey(private)
	return server.Serve()
}