package sessions

import (
	"log"
	"time"
)

// ServeWorker is the title worker
func (s *Session) ServeWorker() {
	for {
		// whenever no one is online, we kill the worker
		if len(Sessions) == 0 {
			break
		}

		// ranges through the sessions executing the title worker
		for _, session := range Sessions {
			err := session.ExecuteBranding(make(map[string]any), "resources", "branding", "title.tfx")
			if err != nil {
				log.Println("(sessions/ServeWorker)", err)
				continue
			}
		}

		// updates every second
		time.Sleep(time.Second)
	}
}