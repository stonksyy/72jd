package db

import (
	"database/sql"
	"hajime/source"

	_ "github.com/glebarez/go-sqlite"
)

var Conn *DB = &DB{
	conn:   new(sql.DB),
	config: new(DBConfig),
}

// DB represents a database connection
type DB struct {
	conn   *sql.DB
	config *DBConfig
}

// DBConfig represents the configuration which is required by the db package
type DBConfig struct {
	DBFile string `json:"database.file"`
}

// Query represents anything which can retrain information for us
type Query interface { Scan(...any) error }

// Connect will attempt to make the connection with the database
func (conn *DB) Connect() error {
	err := source.Options.MarshalFromPath(&conn.config, "database")
	if err != nil {
		return err
	}

	conn.conn, err = sql.Open("sqlite", conn.config.DBFile)
	if err != nil {
		return err
	}

	return conn.conn.Ping()
}